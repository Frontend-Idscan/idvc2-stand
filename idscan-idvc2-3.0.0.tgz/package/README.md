## Overview

Upon being switched on, the library integrates the component of capturing the documents and faces from a video to your page.

## Use cases

- Capture and determination of the document type
- Capture of pdf417
- Capture of MRZ
- Capture of faces
- Capture of QR code

## Demo

Working the library for different cases you can find on our [demo pages](https://demo.idscan.net/).

## Recommendations

Use a modern phone with a good camera having the definition of not less than 8 megapixels.
The capture must be made in a well-lighted room. A document must be located at the uniform background.

## Limitations

This component works in phones with the operating system Android in the browser Chrome (minimum version 93) and in phones with the operating system iOS (minimum version 14) in the browser Safari

## Installation

```
$ npm install @idscan/idvc2
```

This component contains JS files which require the mandatory import into your project.

1. Before importing, it is necessary to set the webpack-configuration.

*Note: The project must use the webpack 4 and later versions.*

1.1. If you prefer to use neural networks from your domain, you should add the &#39;CopyWebpackPlugin&#39; into the section &#39;plugins&#39; which will copy the files, which are necessary for the work of the neural network, from the folder to another folder that should be selected by you.

*Note: The structure inside the folder of the component &#39;networks&#39; must be saved on the server with due regard to the nesting.
There are binary files in the folder which do not have the extension. These files must be provided by the server with the header `Content-Type: application/octet-stream`.*

*copy-webpack-plugin v.5 and below*
```javascript
const CopyWebpackPlugin = require('copy-webpack-plugin');

new CopyWebpackPlugin ([{
  from: 'node_modules/@idscan/idvc2/dist/networks/*',
  to: 'networks/[name].[ext]',
  toType: 'template',
}]);
```
*copy-webpack-plugin v.6 and above*
```javascript
const CopyWebpackPlugin = require('copy-webpack-plugin');

new CopyWebpackPlugin({
  patterns: [
    {
      from: 'node_modules/@idscan/idvc2/dist/networks/*',
      to: 'networks/[name][ext]',
      toType: 'template',
    },
  ],
});
```

1.3. Import the library to your project.

```javascript
import IDVC from '@idscan/idvc2'

```

## Configuration
 Configuration documentation you can find on our [site](https://docs.idscan.net/dvs/dvs-web-api/web-library-v2.html).


*Note: Request a license key for the library by emailing
 [sales@idscan.net](mailto:sales@idscan.net) or [support@idscan.net](mailto:support@idscan.net)*

## Version history

- **3.0.0**
  - feat: added document type information in the 'sumbit' event output parameters
  - feat: when the allowSubmitWithWarnings parameter is set to true, the user will be taken to the step selection screen where the submit button is displayed
  - feat: camera access error text has been changed
  - feat: improved quality of capturing all sides of the document when capturing from the camera
  - feat: dynamically executable code was removed from internal wasm modules

- **2.15.0**
  - feat: document type 'ID' has been removed and split into 2 types: 'DL' & 'IC'. The workflow of these document types is the same as 'ID'
  - feat: added option 'autocaptureConfidence'. The option specifies the strictness of the type recognition decision filter. The value must be a floating point number between 0 and 1. Where 1 is the strictest filter, 0 is the least strict.
  - feat: 'captureTimeout' option and the 'onCaptureTimeout' hook was removed
  - feat: the text of the loader notifications was reworked
  - feat: improved capture quality
  - feat: the 'chunkPublicPath' option is no longer valid. All assets must be stored in the path specified by the 'networkUrl' option
  - feat: added a warning that the camera is off, but it is mandatory in some steps of the document
  - feat: added notification to make the user go to the start screen if submit with warnings is enabled

- **2.14.0**
  - feat: added capture limits depending on document type for the 'front' step. For example, now it will not be possible to validate the 'front' step using a passport if the 'Green Card' document is selected, etc.
  - feat: new pdf track string format in manual upload mode
  - fix: fixed a issue where a user had a non-valid license key, but the web library would still start if the 'autoStart' option was set to true.

- **2.13.0**
  - feat: an option 'enableFourCornerCapture' for back-side steps 'pdf', 'back', 'mrz' (not Passport) has been added. This option allows you to capture 4 corners of the document.
  - feat: changed notification when loading an image with small resolution
  - feat: 'VIN' document type and 'photo' step type have been removed
  - feat: updated text in case there is a camera, but it is not suitable for document validation
  - feat: visual changes for document capture bounding box
  - feat: changed the logic of the document type change button for the case when there is only one document in the configuration
  - fix: removed the ability to capture a document through page element code manipulation
  - fix: spanish language UI issues
  - fix: the 'Plus' element on the page was blinking in case the user uploaded the document using the Drag&Drop events
  - fix: even if the 'fixFrontOrientAfterUpload' option is set to true, incorrect documents will not be rotated, but will be displayed in their original form along with a warning message

- **2.12.2**
  - feat: improved manual upload capture

- **2.12.1**
  - fix: error when calling the reloadComponent method
  - fix: the spinner was partially displayed on iOS devices

- **2.12.0**
  - feat: improved capture of the back side of the document on the 'pdf' step type. Now the entire back side with 4 corners is captured
  - feat: css styles are now embedded on the page automatically. no need to import them manually anymore
  - feat: all round loaders have been replaced by cubes
  - fix: corrected arrow direction display when capturing a face
  - fix: loader did not close with “ isShowDocumentTypeSelect: false” and “ autoStart : true” enabled at the same time

- **2.11.1**
  - feat: added face check on document in 'front' step
  - feat: added check that all 4 corners of the document are in the frame at the 'front' step
  - feat: added new option 'captureTimeout' - This option allows you to set a timer in seconds, how long after the start of video capture the hook 'onCaptureTimeout' will be triggered
  - feat: added new hook 'onCaptureTimeout' - Callback-function which will be called after the user failed to capture the document from the camera in the time specified by the 'captureTimeout' option
  - feat: added text in spinner, after auto submitting the collected images

- **2.11.0**
  - fix: the message of supported documents has been changed
  - feat: new option “playPreviewAnimations” that allows you to turn off step preview animations
  - feat: new option “autoStart” that allows you not to display the document selection and step selection screens when selecting a document

- **2.10.4**
  - fix: web library opens in the label "Second step" when selecting another document
  - fix: step block scrolling speed is reduced
  - fix: the button for closing the document change popup
  - fix: the hover effect changes the width of the container
  - fix: settings are not applied after calling the settings update method
  - feat: rework step processing notifications

- **2.10.3**
  - fix: ui error when one document is enabled and uploader is disabled.

- **2.10.2**
  - feat: the "Green Card or Employment Authorization" document type has been separated into two types: GC (type 6) and EA (type 9).

- **2.10.1**
  - fix: UI: line breaks in step names
  - fix: UI: green outline is shown if configure only face step in the config
  - fix: UI: initialization issues

- **2.10.0**
  - feat: the UI has been completely updated
  - feat: added option 'allowSubmitWithWarnings'
  - feat: the 'hideDocumentTitle' option is deprecated
  - feat: obsolete modules have been removed

- **2.9.0**
  - feat: added a new public method to show the loader.
    Method: showLoader(val: boolean, bottomText?: string, topText?: string)
  - feat: improved document recognition and detection.
  - fix: license error display

- **2.8.11**
  - fix: spinner does not close after config update

- **2.8.10**
  - feat: added a notification that the license key has expired
  - feat: added processing of asynchronous actions in the 'submit' hook
  - fix: removing the track string in the 'back' step in case of incorrect loading
  - feat: when setting the 'showSubmitBtn' option to false, the 'submit' event triggers,
  - a spinner appears that spins all the time the 'submit' hook is processing

- **2.8.7**
  - fix: removed video listeners when the idvc-component was unmounted from the DOM-tree

- **2.8.6**
  - feat: reduced download time due to the use of gzip compression
  - feat: chunk loading order changed

- **2.8.5**
  - feat: added support of more device languages for ios devices
  - fix: license check for PDF module

- **2.8.4**
  - fix: cdn path

- **2.8.3**
  - feat: move pdf module to web worker
  - feat: added initial loader icon
  - feat: added runtime chunks downloading before document select
  - fix: switching button bug
  - fix: added EXIF error handling
  - changed video mirroring behavior
  - changed desktop notification text on mrz step

- **2.8.2**
  - fix: pdf processing on iOS
  - fix: optimize bundle size

- **2.8.1**
  - feat: added 'enableDesktopNotification' option in documentTypes.steps configs
  - feat: added 'autocaptureDelay' option in documentTypes.steps configs
  - feat: changed hold text hint
  - feat: add new pdf reader, that works with manual uploading

- **2.8.0**
  - feat: the 'mrz' step type is now processing front and mrz for Passports
  - feat: added aspect ratio parameter for capturing
  - fix: mrz processing text hint
  - fix: mrz capturing on iOS 17+

- **2.7.8**
  - fix: downloading MRZ on passport document

- **2.7.7**
  - fix: 'back' autocapture processing
  - feat: IDScan branding

- **2.7.6**
  - changed: processing flow - PDF capture is now preferred in the Driver's License

- **2.7.5**
  - feat: do not initialize camera in upload mode
  - fix: chunks downloading from CDN

- **2.7.4**
  - fix: camera for ios 17
  - feat: change Passport card naming on US Passport Card
  - feat: options 'chunkPublicPath' & 'networkUrl' are working correctly now

- **2.7.3**
  - fix: "Uncaught runtime errors" in react spa
  - feat: Changed error message
  - fix: Type declaration for validate method
  
- **2.7.2**
  - fix: Type declaration imports

- **2.7.1**
  - fix: Bad quality barcodes were parsed with errors when manually loaded

- **2.7.0**
  - feat: simplify the Passport verification, now front step it's union of front and mrz
  - feat: changed isShowDocumentTypeSelect behaviour
  - fix: MacBook & IMac camera initialization on start up
  - fix: error message includes html tags

- **2.6.2**
  - feat: new warnings
  - feat: updated the text for the Driver's License Document type 
  - fix: camera processing for Google Pixel 7
  - feat: shut down MediaStream session when the IDVC instance is unloaded
  - fix: IDVC exported types
  
- **2.6.1**
  - fix: fix camera on iPhone 14

- **2.6.0**
  - feat: added international back processing
  - feat: The 'isShowDocumentTypeSelect' option now does not affect to library behavior if there are multiple document types in the configuration
  - fix: the 'realFaceMode' option is not updated after reloading the component

- **2.5.12**
  - feat: changed networks initialization process

- **2.5.11**
  - feat: added warning if background is too much on face uploading
  - feat: changed camera display error

- **2.5.10**
  - feat: added 'hideDocumentTitle' option
  - feat: added 'processingImageFormat' option
  - feat: added normalization for paths

- **2.5.9**
  - feat: have improved capturing processes
  - feat: have changed cdn path

- **2.5.8**
  - fixed: missing network folder
  
- **2.5.7**
  - fixed: pdf barcode capturing

- **2.5.6**
  - fixed: spinner reloading

- **2.5.5**
  - some minor improvements

- **2.5.4**
  - fixed: spinner loading on resetAllSteps method

- **2.5.3**
  - added: preload neural network executor
  - added: minimal perimeter requirements 
  - added: select document type modal position option.
    "modalPosition": "top" | "bottom" | "center" | "sticky-top" | "sticky-bottom"
  - changed: select document type behaviour
  - changed: MRZ warning text

- **2.5.2**
  - fixed: IDocumentTypeConfig in types declaration

- **2.5.1**
  - fixed: check camera is busy for iPhone

- **2.5.0**
  - added: improved PDF detection
  - added: Australia DLIC support
  - added: check uploaded image for minimal resolution (wider side should be minimum 600px)
  - added: set webP as default image format
  - added: onnx framework
  - added: default font size to 1rem;
  - changed: realface capturing calculates by X coordinate
  - changed: improved step processing speed
  - removed: "isSubmitMetaData" option
  - removed: tfjs framework
  - fixed: check icon position

- **2.4.17**
  - feat: improved frame quality analyze for the front step
  - feat: added types declaration

- **2.4.16**
  - feat: change icon to svg
  - fixed: ui
  - added: version method

- **2.4.15**
  - feat: close selectDocumentType modal on reload, if option isShowDocumentTypeSelect is false and Lib processing a single document type

- **2.4.14**
  - fix: compressed version info to metadata field
  
- **2.4.13**
  - added: version info to metadata field

- **2.4.12**
  - fixed: if canvas element is null, lib sets default values for canvas

- **2.4.11**
  - added: onReloaded callback - it fires after reloadComponent method is completed

- **2.4.10**
  - fixed: spinner after config update
  
- **2.4.9**
  - added: licence key checks on start of weblib
  - added: reduced pdf frames to 1

- **2.4.8**
  - fixed: camera select

- **2.4.7**
  - fixed: turning on the selfie camera instead of the back one on iPhones

- **2.4.6**
  - fixed: component doesn't work after remount
  - fixed: spinner holds after the document was changed in uploader mode
  - fixed: simple face detection if no camera
  - feat: removed unused code
  - feat: front image processing speed improvements
  - feat: improved memory usage
- **2.4.5**
  - feat: added support for iOS < 15
- **2.4.4**
  - language support improvement 
- **2.4.3**
  - fixed: behaviour without filled "documentTypes" config field
- **2.4.2**
  - fixed: spinner on document type select
  - fixed: loading chunks when the camera is not supported
- **2.4.1**
  - fixed: "resetAllSteps" method on uploader mode
- **2.4.0**
  - added: new option in config "showSubmitBtn"
  - improved step mode validation
- **2.3.3**
  - fixed: barcode video capture in the "qrcode" step
- **2.3.2**
  - fixed: uploader mode
  - added: translation spinner text
- **2.3.1**
  - added: barcode result in step data
- **2.3.0**
  - added: new option in config "chunkPublicPath"
- **2.2.3**
  - fixed: switch manual upload button
- **2.2.2**
  - fixed: spinner module
- **2.2.1**
  - fixed: spinner on manual upload
- **2.2.0**
  - fixed: video container
  - fixed: force image capture button
  - feature: check for blur
  - feature: reduced loading time
  - feature: reduced image capturing time
  - feature: new liveness checks
  - updated: pdf and mrz modules
  - feature: lazy async loading
  - fixed: flashlight state on step change
  - updated: neuron networks
  - feature: new hook updateDocumentTypes
- **2.1.6**
  - Fixed css variable
- **2.1.5**
  - Added limitations check
- **2.1.4**
  - fixed event listeners behavior on restart component
- **2.1.3**
  - fixed reload component method
- **2.1.2**
  - fixed change document type
- **2.1.1**
  - updated camera module
  - improved camera errors handling
- **2.1.0**
  - removed additional fonts
  - added step swiping if an image is uploaded
  - changed front document capturing method
  - improved mrz parsing
  - fixed bubbling if an image is mirrored 
  - reduced library size
  - added new css variable for library's font family
  - reduced css
  - added blur detector to front step
  - improved MRZ location and MRZ decode speed.
  - moved HEIC supports to distinct module and added additional config option for it.
  - reduced first loading time.
  - removed "parsePDF" option.
  - added "mrzImg" field to mrz step. It's cut mrz for better MRZ recognition on DVS side.
- **2.0.2**
  - fix: manual upload.
- **2.0.1**
  - deprecated: isShowManualSwitchButton. Now the decision is made on a step config
  - deprecated: enableFlash. Now it shows only if device/browser supports flashlight.
  - deprecated: showSubmitBtn. The submit button is always turned on.
  - deprecated: isShowVersion. The Library version is always showing.
  - deprecated: tapOnVideo.
  - deprecated: tapBackSide.
  - deprecated: tapFace.
  - deprecated: showForceCapturingBtn.
  - deprecated: minPDFframes.
  - deprecated: capturingMode.
  - deprecated: showPreviewForOneStep.
  - deprecated: priority. Now the priority is selected by camera availability.
  - deprecated: parseMRZ.
  - deprecated: enableGeolocation.
  - deprecated: enableLimitation. Now limitation shows only if the system not supports needed features.
  - deprecated: steps.
  - deprecated: types.
  - deprecated: displayParsedData.
  - changed behavior: autoContinue.
  - feat: documentTypes. Now the "documentTypes" option is a union of steps and types.
  - feat: add translation.
